import javax.swing.*;

public class Driver {
    public static void main(String[] args) throws Exception {
        JFrame frame = new CustomJFrame();
    }
}
